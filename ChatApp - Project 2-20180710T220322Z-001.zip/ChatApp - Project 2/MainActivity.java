package com.example.macstudent.chatapp;


import android.annotation.TargetApi;
import android.icu.util.Calendar;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Comment;

public class MainActivity extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference rootnode;
    FirebaseAuth mAuth;
    public String email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        database = FirebaseDatabase.getInstance();
        rootnode = database.getReference();
        mAuth = FirebaseAuth.getInstance();

    }
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }


    private void updateUI(FirebaseUser currentUser) {

        if (currentUser != null) {
            ((TextView) findViewById(R.id.lbluser)).setText(
                    "User ID: " + currentUser.getUid());
        } else {
            ((TextView) findViewById(R.id.lbluser)).setText(
                    "Error: sign in failed.");
        }
    }


    @android.support.annotation.RequiresApi(api = Build.VERSION_CODES.N)
    public void btnClick(View v){
//For Message
        EditText msg = (EditText) findViewById(R.id.edtmsg);
        String msgstring = msg.getText().toString();

//For Date-Time
        Calendar cal = Calendar.getInstance();
        String date = cal.getTime().toString();
        Log.d("Date::::", date);
        EditText username = findViewById(R.id.edtusername);
        email = username.getText().toString();

        ChatMessage takemsg = new ChatMessage(msgstring,date,email);

        rootnode.child("Chat").push().setValue(takemsg);
        Log.d("Message: " + email + "says: ",  msgstring );
        TextView dates = findViewById(R.id.lbldate);
        dates.setText(date);


        ChildEventListener childEventListener = new ChildEventListener() {

            public String TAG;
            TextView lbl = findViewById(R.id.lblmsg);
            TextView lbl1 = findViewById(R.id.lbluser);
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String previousChildName) {
                Log.d(TAG, "onChildAdded:" + dataSnapshot.getKey());

                // A comment has changed, use the key to determine if we are displaying this
                // comment and if so displayed the changed comment.
                ChatMessage newComment = dataSnapshot.getValue(ChatMessage.class);
                String y = newComment.message;
                String e = newComment.email;
                Log.d("Email: " + e + " Comment: ", y);
                lbl.setText("New Message added");


            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String previousChildName) {
                String key = rootnode.push().getKey();
               // String commentKey = dataSnapshot.child().getKey();
                /*
                Log.d("Changed Value::",key);
                lbl.setText("Message Changed");
                lbl1.setText("User Email id Change");*/
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
               
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String previousChildName) {
                
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
               
            }
        };
        rootnode.child("Chat").addChildEventListener(childEventListener);
    }

    public void btnLogin(View v){
        EditText username = findViewById(R.id.edtusername);
        EditText password = findViewById(R.id.edtpassword);

        String email = username.getText().toString();
        String pwd = password.getText().toString();

        if(TextUtils.isEmpty(email) && TextUtils.isEmpty(pwd)){

            Toast.makeText(MainActivity.this, "Please Enter UserName and Password",Toast.LENGTH_LONG).show();
        }

        mAuth.signInWithEmailAndPassword(email, pwd)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    public String TAG;

                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithEmail::::::::success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.d(TAG, "signInWithEmail::::::::::::::::failure", task.getException());
                            Toast.makeText(MainActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }

                        // ...
                    }
                });

    }
    public void btnLogout(View v){

       mAuth.signOut();
        Toast.makeText(MainActivity.this, "Logged out Successfully...",
                Toast.LENGTH_SHORT).show();
        Log.d("LogOut" , email);


    }

    public void Add(View v){


    }
}
