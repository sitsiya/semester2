package com.example.macstudent.chatapp;

/**
 * Created by macstudent on 2017-12-05.
 */

public class ChatMessage {
    public String message;
    public String datetime;
    public String email;

    public ChatMessage(){

    }

    public ChatMessage(String msg, String dt,String emailid)
    {
        this.message = msg;
        this.datetime = dt;
        this.email = emailid;
    }

    public void setMessage(String message,String datetime,String emailid) {
        this.message = message;
        this.datetime = datetime;
        this.email = emailid;
    }
}
