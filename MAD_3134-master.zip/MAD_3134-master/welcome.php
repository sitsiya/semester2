<html>
<body>
Welcome<?php echo $_POST["name"];?><br><br>
Your Email Address is: <?php echo $_POST["email"];?>

</body>
</html>
