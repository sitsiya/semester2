<html>
<head>
<title>Admin Department</title>
<style>

body{
	background-color: azure;
	margin-top: 50px;
}
h1{
	color: navy;
}
.btn{
	border-radius: 20px;
	background-color: white;
	color: coral;
}
.label{
	color: cornflowerblue;
}

</style>
</head>
<body>
<h1>Checkout Success</h1>
<form action="UserSummary.php" method="post">
<input class="btn" type="submit" value="Back"/>
</form>
</body>
</html>
