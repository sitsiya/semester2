
<html>
<body>
<h1>Popular Book Report</h1>
<form action="SearchBooks.php" method="post">

<table border="1" style="width:100%">
  <tr>
    <th>Month</th>
    <th>Title</th>
    <th>#chechouts</th>
  </tr>
  <tr>
    <td>Jill</td>
    <td>Smith</td>
    <td>50</td>
  </tr>
  <tr>
    <td>Eve</td>
    <td>Jackson</td>
    <td>94</td>
  </tr>
</table>


</body>
</html>