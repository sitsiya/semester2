<?php

$user = 'root';
$pass = '';
$host = 'localhost';   
$database = 'library';
?>