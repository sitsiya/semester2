//
//  ViewController.swift
//  UnicornRewards
//
//  Created by robin on 2017-11-07.
//  Copyright © 2017 robin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // ==================================
    // SUBMITTED BY:
    //  CHAITALIBEN PATEL   C0697976
    //  BRIJESH PRAJAPATI   C0707229
    // ==================================
    
    
    // outlets
    
    @IBOutlet weak var btncoffee: UISwitch!
    @IBOutlet weak var btncookie: UISwitch!
    @IBOutlet weak var btnpizza: UISwitch!
    @IBOutlet weak var lblreward: UILabel!
    @IBOutlet weak var reward: UILabel!
    
    // variables
    var x = 0
    var point = 0
    
    // actions
    
    @IBAction func btncheck(_ sender: UIButton) {
        if(btncoffee.isOn == true && btncookie.isOn == true && btnpizza.isOn == true){
            x = 105
          //  lblreward.text = "Total Reward Points: \(x) pts"
            
                    }
        else if(btnpizza.isOn == true && btncookie.isOn == true){
            x = 95
          //  lblreward.text = "Total Reward Points: \(x) pts"
            
            
        }
        else if(btnpizza.isOn == true && btncoffee.isOn == true){
            x = 85
          //  lblreward.text = "Total Reward Points: \(x) pts"
           
           
        }
        else if(btncoffee.isOn == true && btncookie.isOn == true){
            x = 30
          //  lblreward.text = "Total Reward Points: \(x) pts"
            
           
        }
        else if(btncoffee.isOn == true){
            x = 10
          //  lblreward.text = "Total Reward Points: \(x) pts"
            
            
        }
        else if(btncookie.isOn == true){
            x = 20
         //   lblreward.text = "Total Reward Points: \(x) pts"
            
            
        }
        else if(btnpizza.isOn == true){
            x = 75
          //  lblreward.text = "Total Reward Points: \(x) pts"
            
            
        }

        else{
        x = 0
       // lblreward.text = "Total Reward Points: \(x) pts"
           
           
        }
        lblreward.text = "Total Reward Points: \(x) pts"
    }
    

    @IBAction func btncoffeerwd(_ sender: UIButton) {
        if(x >= 25){
        lblreward.text = "Total Reward Points: \(x - 25) pts"
        }
        else {
            lblreward.text = "Not Enough pts"
        }
        
    }
    
    @IBAction func btncerty(_ sender: UIButton) {
        
        if(x >= 100){
            lblreward.text = "Total Reward Points: \(x - 100) pts"
        }
        
        else {
            
            lblreward.text = "insufficient points"
            
        }
    }
    
}

